package com.sree.pra.praex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraexApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraexApplication.class, args);
	}

}
