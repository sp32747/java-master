package com.sree.pra.praex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraexApplicationTests {

	@Test
	void contextLoads() {
	}

}
